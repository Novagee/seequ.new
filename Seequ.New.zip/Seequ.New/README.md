# Seequ iOS Client
[![Build Status](https://build.seequ.com:8443/plugins/servlet/wittified/build-status/SI-IOS)](https://build.seequ.com:8443/browse/SI-IOS/latest)
