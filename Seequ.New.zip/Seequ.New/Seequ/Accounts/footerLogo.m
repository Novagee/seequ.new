//
//  footerLogo.m
//  Seequ
//
//  Created by peng wan on 15-2-7.
//  Copyright (c) 2015 Seequ. All rights reserved.
//

#import "footerLogo.h"
#import "App_StyleKit.h"

@implementation footerLogo

- (void)drawRect:(CGRect)rect {
    // Drawing code
        [App_StyleKit drawLogin_footer_logo];
}

@end
