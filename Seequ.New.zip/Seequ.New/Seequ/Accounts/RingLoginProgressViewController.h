//
//  RingLoginProgressViewController.h
//  Seequ
//
//  Created by peng wan on 15-2-13.
//  Copyright (c) 2015 Seequ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RingLoginProgressViewController : UIViewController

@property (nonatomic, copy)NSString *email;
@property (nonatomic, copy)NSString *password;

@end
