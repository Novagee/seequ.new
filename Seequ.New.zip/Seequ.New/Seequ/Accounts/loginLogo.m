//
//  loginLogo.m
//  Seequ
//
//  Created by peng wan on 15-2-8.
//  Copyright (c) 2015 Seequ. All rights reserved.
//

#import "loginLogo.h"
#import "App_StyleKit.h"

@implementation loginLogo

- (void)drawRect:(CGRect)rect {

    [App_StyleKit drawLogin_logoWithProgressPercent:100];
}

@end
