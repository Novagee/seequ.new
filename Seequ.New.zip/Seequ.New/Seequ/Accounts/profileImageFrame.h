//
//  profileImageFrame.h
//  Seequ
//
//  Created by peng wan on 15-2-8.
//  Copyright (c) 2015 Seequ. All rights reserved.
//

#import <UIKit/UIKit.h>

IB_DESIGNABLE

@interface profileImageFrame : UIView

@end
