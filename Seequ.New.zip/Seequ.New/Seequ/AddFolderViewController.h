//
//  AddFolderViewController.h
//  Seequ
//
//  Created by Peng Wan on 3/3/15.
//  Copyright (c) 2015 Seequ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddFolderViewController : UIViewController

@property (strong, nonatomic) NSString *currentBookmarkDirectoryPath;

@end
