
@import UIKit;
@import Foundation;


@interface RingContactsViewController : UIViewController

@end
