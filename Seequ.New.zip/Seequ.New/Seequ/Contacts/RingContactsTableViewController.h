
@import UIKit;
@import Foundation;


@interface RingContactsTableViewController : UITableViewController

@property (nonatomic, copy) NSArray *model; //Array of RingAddressBookContact objects

@end
