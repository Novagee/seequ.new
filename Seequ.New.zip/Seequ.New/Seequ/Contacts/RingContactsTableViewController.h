//
//  RingContactsTableViewController.h
//  Seequ
//
//  Created by Jose Correa on 2/6/15.
//  Copyright (c) 2015 Seequ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RingContactsTableViewController : UITableViewController

@end
