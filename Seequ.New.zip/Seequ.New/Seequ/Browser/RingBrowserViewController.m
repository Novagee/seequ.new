//
//  RingBrowserViewController.m
//  Seequ
//
//  Created by Jose Correa on 2/6/15.
//  Copyright (c) 2015 Seequ. All rights reserved.
//

#import "RingBrowserViewController.h"
#import "RingBrowserNavBarTextfield.h"
#import "RingBrowserButton.h"
#import "RingBrowserRefreshButton.h"

#import <WebKit/WebKit.h>

static CGFloat const navBarHeight = 66.0f;
static CGFloat const tabBarHeight = 49.0f;

@interface RingBrowserViewController ()
@property (weak, nonatomic) IBOutlet RingBrowserButton *prevArrowButton;
@property (weak, nonatomic) IBOutlet RingBrowserButton *nextArrowButton;
@property (weak, nonatomic) IBOutlet RingBrowserButton *buddyBrowserButton;
@property (weak, nonatomic) IBOutlet RingBrowserButton *bookmarkButton;
@property (strong, nonatomic) WKWebView *webView;
@property (weak, nonatomic) IBOutlet RingBrowserNavBarTextfield *browserURLTextfield;
@end

@implementation RingBrowserViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    self.webView = [[WKWebView alloc] initWithFrame: CGRectMake(0, navBarHeight, self.view.frame.size.width, self.view.frame.size.height - navBarHeight - tabBarHeight)];
                          
    NSURL *url = [NSURL URLWithString:@"http://cnn.com"];
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    [self.webView loadRequest:request];
    [self.view addSubview:self.webView];
    
    UIButton *refreshButton = [UIButton buttonWithType:UIButtonTypeCustom];
    refreshButton.frame = CGRectMake(0, 0, 12, 12);
    [refreshButton setImage:[UIImage imageNamed:@"brower_refresh"] forState:UIControlStateNormal];
    [refreshButton addTarget:self action:@selector(browserURLTextfieldRefreshButtonTouchUpInside:) forControlEvents:UIControlEventTouchUpInside];

//    RingBrowserRefreshButton *button = [RingBrowserRefreshButton new];
    self.browserURLTextfield.rightView = refreshButton;
    self.browserURLTextfield.text = @"http://www.cnn.com";
    self.browserURLTextfield.rightViewMode = UITextFieldViewModeAlways;
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Control's Actions

- (void)browserURLTextfieldRefreshButtonTouchUpInside:(id)sender {
    
    [self.webView reload];
    
}

- (IBAction)prevArrowClick:(id)sender {
    [self.webView stopLoading];
    [self.webView goBack];
}

- (IBAction)nextArrowClick:(id)sender {
    [self.webView stopLoading];
    [self.webView goForward];
}
- (IBAction)bookmarkClick:(id)sender {
}

@end
