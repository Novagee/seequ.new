//
//  RingBrowserNavBarTextfield.h
//  Seequ
//
//  Created by peng wan on 15-2-26.
//  Copyright (c) 2015 Seequ. All rights reserved.
//

#import <UIKit/UIKit.h>

IB_DESIGNABLE

@interface RingBrowserNavBarTextfield : UITextField

@end
