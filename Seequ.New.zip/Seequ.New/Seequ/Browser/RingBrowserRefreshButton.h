//
//  RingBrowserRefreshButton.h
//  Seequ
//
//  Created by peng wan on 15-3-1.
//  Copyright (c) 2015年 Seequ. All rights reserved.
//

#import <UIKit/UIKit.h>

IB_DESIGNABLE
@interface RingBrowserRefreshButton : UIButton

@end
