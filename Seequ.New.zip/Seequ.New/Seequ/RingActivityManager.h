//
//  RingActivityManager.h
//  Seequ
//
//  Created by peng wan on 15-3-9.
//  Copyright (c) 2015年 Seequ. All rights reserved.
//

#import "RingAPIManager.h"

@interface RingActivityManager : RingAPIManager

+(instancetype)sharedInstance;

@end
