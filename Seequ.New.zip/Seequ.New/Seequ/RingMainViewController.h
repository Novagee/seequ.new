//
//  RingMainViewController.h
//  Seequ
//
//  Created by peng wan on 15-2-10.
//  Copyright (c) 2015 Seequ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RingMainViewController : UITabBarController

@end
