//
//  UserStatus.m
//  Seequ.Next
//
//  Created by peng wan on 14-10-18.
//  Copyright (c) 2015 Seequ. All rights reserved.
//

#import "UserStatus.h"

@implementation UserStatus

@end
