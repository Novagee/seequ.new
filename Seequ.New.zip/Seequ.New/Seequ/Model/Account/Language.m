//
//  Language.m
//  Seequ.Next
//
//  Created by Peng Wan on 10/17/14.
//  Copyright (c) 2015 Seequ. All rights reserved.
//

#import "Language.h"

@implementation Language

@end
