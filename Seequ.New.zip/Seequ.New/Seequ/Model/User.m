
#import "User.h"


@implementation User

+ (NSString *)primaryKey {
    return @"_id";
}

@end
