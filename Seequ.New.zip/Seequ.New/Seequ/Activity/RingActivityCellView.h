//
//  RingActivityCellView.h
//  Seequ
//
//  Created by peng wan on 15-3-9.
//  Copyright (c) 2015年 Seequ. All rights reserved.
//

#import <UIKit/UIKit.h>

IB_DESIGNABLE

@interface RingActivityCellView : UIView

@end
